# Linear Search Implementation

# Step 1: Take input for the list
user_input = input("Enter the list elements separated by spaces: ")
my_list = user_input.split()

# Optional: Convert to integers if needed
# my_list = list(map(int, my_list))

# Step 2: Take input for the item to search
item_to_find = input("Enter the item to search: ")

# Step 3: Linear Search Function
def linear_search(lst, target):
    for index, item in enumerate(lst):
        if item == target:
            return index  # Return index if found
    return -1  # Return -1 if not found

# Step 4: Call the function and show the result
result = linear_search(my_list, item_to_find)

if result != -1:
    print(f"Item '{item_to_find}' found at index {result}.")
else:
    print(f"Item '{item_to_find}' not found in the list.")
